import 'dart:convert';

import 'package:uuid/uuid.dart';

import '../../core/database/database_helper.dart';
import '../../core/database/db_schema.dart';
import '../models/account.dart';

class AccountRepository {
  AccountRepository(this._dbHelper);

  final DatabaseHelper _dbHelper;
  static const Uuid _uuid = Uuid();

  Future<Account> createAccount({
    required String name,
    required String type,
    required String currency,
    int? businessEntityId,
  }) async {
    final db = await _dbHelper.database;
    final String now = DateTime.now().toIso8601String();
    final String accountUuid = _uuid.v4();
    final int id = await db.insert(DbSchema.tableAccounts, <String, Object?>{
      'uuid': accountUuid,
      'name': name,
      'type': type,
      'currency': currency,
      'running_balance': 0,
      'running_balance_usd': 0,
      'status': 'active',
      'is_system': 0,
      'business_entity_id': businessEntityId,
      'created_at': now,
    });
    await db.insert(DbSchema.tableAuditLog, <String, Object?>{
      'entity_type': 'account',
      'entity_id': id,
      'action': 'created',
      'old_values': null,
      'new_values': jsonEncode(<String, Object?>{'name': name, 'type': type, 'currency': currency}),
      'changed_by': null,
      'changed_at': now,
    });
    return Account(
      id: id,
      uuid: accountUuid,
      name: name,
      type: type,
      currency: currency,
      businessEntityId: businessEntityId,
      createdAt: now,
    );
  }

  Future<List<Account>> getAccounts({String? type, String status = 'active'}) async {
    final db = await _dbHelper.database;
    final String where = type != null ? 'type = ? AND status = ?' : 'status = ?';
    final List<Object?> whereArgs = type != null ? [type, status] : [status];
    final rows = await db.query(
      DbSchema.tableAccounts,
      where: where,
      whereArgs: whereArgs,
      orderBy: 'name ASC',
    );
    return rows.map(Account.fromMap).toList();
  }

  Future<Account?> getById(int id) async {
    final db = await _dbHelper.database;
    final rows = await db.query(DbSchema.tableAccounts, where: 'id = ?', whereArgs: [id]);
    if (rows.isEmpty) return null;
    return Account.fromMap(rows.first);
  }

  Future<void> archiveAccount(int id) async {
    final db = await _dbHelper.database;
    final String now = DateTime.now().toIso8601String();
    await db.update(
      DbSchema.tableAccounts,
      <String, Object?>{'status': 'archived'},
      where: 'id = ?',
      whereArgs: [id],
    );
    await db.insert(DbSchema.tableAuditLog, <String, Object?>{
      'entity_type': 'account',
      'entity_id': id,
      'action': 'status_changed',
      'old_values': null,
      'new_values': jsonEncode(<String, Object?>{'status': 'archived'}),
      'changed_by': null,
      'changed_at': now,
    });
  }
}
