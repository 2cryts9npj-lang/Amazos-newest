class FiscalYear {
  const FiscalYear({
    this.id,
    required this.name,
    required this.startDate,
    required this.endDate,
    this.isClosed = false,
  });

  final int? id;
  final String name;
  final String startDate;
  final String endDate;
  final bool isClosed;

  Map<String, Object?> toMap() => <String, Object?>{
        if (id != null) 'id': id,
        'name': name,
        'start_date': startDate,
        'end_date': endDate,
        'is_closed': isClosed ? 1 : 0,
      };

  factory FiscalYear.fromMap(Map<String, Object?> map) => FiscalYear(
        id: map['id'] as int?,
        name: map['name']! as String,
        startDate: map['start_date']! as String,
        endDate: map['end_date']! as String,
        isClosed: (map['is_closed']! as int) == 1,
      );
}
