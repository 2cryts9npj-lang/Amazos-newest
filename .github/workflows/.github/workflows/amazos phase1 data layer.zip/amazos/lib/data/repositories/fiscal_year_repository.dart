import '../../core/database/database_helper.dart';
import '../../core/database/db_schema.dart';
import '../models/fiscal_year.dart';

class FiscalYearRepository {
  FiscalYearRepository(this._dbHelper);

  final DatabaseHelper _dbHelper;

  Future<FiscalYear> create({
    required String name,
    required String startDate,
    required String endDate,
  }) async {
    final db = await _dbHelper.database;
    final int id = await db.insert(DbSchema.tableFiscalYears, <String, Object?>{
      'name': name,
      'start_date': startDate,
      'end_date': endDate,
      'is_closed': 0,
    });
    return FiscalYear(id: id, name: name, startDate: startDate, endDate: endDate);
  }

  Future<List<FiscalYear>> getAll() async {
    final db = await _dbHelper.database;
    final rows = await db.query(DbSchema.tableFiscalYears, orderBy: 'start_date DESC');
    return rows.map(FiscalYear.fromMap).toList();
  }

  /// Closed years reject new movements — enforced by the caller
  /// (MovementRepository checks fiscal year status before posting) since
  /// that validation belongs with the write path, not here.
  Future<void> close(int id) async {
    final db = await _dbHelper.database;
    await db.update(
      DbSchema.tableFiscalYears,
      <String, Object?>{'is_closed': 1},
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
