import 'dart:convert';

import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

import '../../core/database/database_helper.dart';
import '../../core/database/db_schema.dart';
import '../../core/utils/money.dart';
import '../models/movement.dart';
import '../models/movement_line.dart';

/// Posts and reverses movements. This is deliberately a generic,
/// currency-agnostic engine: it knows how to insert a balanced set of
/// lines atomically and keep account balances correct. It does NOT know
/// about currency-exchange semantics (average cost, realized gain/loss)
/// — that belongs to a Phase 2 CurrencyExchangeService that computes the
/// right [MovementLineInput]s (using [Money.averageCostRate]) and calls
/// [postMovement]. Keeping that logic out of this repository is a
/// deliberate layering choice, not an oversight.
class MovementRepository {
  MovementRepository(this._dbHelper);

  final DatabaseHelper _dbHelper;
  static const Uuid _uuid = Uuid();

  /// Posts a new movement made of one or more lines, atomically:
  /// sequential-number assignment, line inserts, account balance updates,
  /// and the audit log entry all happen inside a single db transaction.
  /// If anything throws, sqflite rolls the whole transaction back.
  Future<Movement> postMovement({
    required String date,
    required String time,
    required List<MovementLineInput> lines,
    String? note,
    String? noteLevel,
    int? fiscalYearId,
    bool isOpeningBalance = false,
    String? createdBy,
  }) async {
    if (lines.isEmpty) {
      throw ArgumentError('A movement must contain at least one line');
    }
    for (final MovementLineInput line in lines) {
      if (line.amount <= 0) {
        throw ArgumentError('Line amount must be positive');
      }
      if (line.exchangeRateDenominator == 0) {
        throw ArgumentError('Exchange rate denominator cannot be zero');
      }
      if (line.fromAccountId == line.toAccountId) {
        throw ArgumentError('A line cannot move money to the same account it came from');
      }
    }

    final Database db = await _dbHelper.database;
    late Movement result;

    await db.transaction((Transaction txn) async {
      // 1. Validate every account referenced actually exists and is active.
      final Set<int> accountIds = <int>{};
      for (final MovementLineInput line in lines) {
        accountIds
          ..add(line.fromAccountId)
          ..add(line.toAccountId);
      }
      for (final int accountId in accountIds) {
        final rows = await txn.query(
          DbSchema.tableAccounts,
          where: 'id = ?',
          whereArgs: [accountId],
        );
        if (rows.isEmpty) {
          throw StateError('Account $accountId does not exist');
        }
        if (rows.first['status'] != 'active') {
          throw StateError('Account $accountId is not active (status: ${rows.first['status']})');
        }
      }

      // 2. Assign the next sequential number.
      //
      // Single-writer assumption: sqflite serializes all writes on this
      // one connection, so a MAX+1 read-then-insert inside this same
      // transaction is safe for a single-device, single-user app. If
      // Amazos ever gains a second writer (multi-device sync, V3+), this
      // must move to a dedicated atomic counter table — flagging that
      // now so it isn't rediscovered as a bug later.
      final seqRows = await txn.rawQuery(
        'SELECT COALESCE(MAX(sequential_number), 0) + 1 AS next_seq '
        'FROM ${DbSchema.tableMovements}',
      );
      final int sequentialNumber = seqRows.first['next_seq']! as int;

      // 3. Insert the movement header.
      final String now = DateTime.now().toIso8601String();
      final String movementUuid = _uuid.v4();
      final int movementId = await txn.insert(DbSchema.tableMovements, <String, Object?>{
        'uuid': movementUuid,
        'sequential_number': sequentialNumber,
        'date': date,
        'time': time,
        'status': 'posted',
        'note': note,
        'note_level': noteLevel,
        'is_opening_balance': isOpeningBalance ? 1 : 0,
        'is_locked': 0,
        'fiscal_year_id': fiscalYearId,
        'reversal_of_movement_id': null,
        'created_by': createdBy,
        'created_at': now,
        'posted_at': now,
      });

      // 4. Insert lines and apply balance deltas.
      int lineNumber = 1;
      for (final MovementLineInput line in lines) {
        final int amountUsd = Money.toUsdCents(
          amountMinorUnits: line.amount,
          rateNumerator: line.exchangeRateNumerator,
          rateDenominator: line.exchangeRateDenominator,
        );

        await txn.insert(DbSchema.tableMovementLines, <String, Object?>{
          'movement_id': movementId,
          'line_number': lineNumber,
          'from_account_id': line.fromAccountId,
          'to_account_id': line.toAccountId,
          'amount': line.amount,
          'currency': line.currency,
          'exchange_rate_numerator': line.exchangeRateNumerator,
          'exchange_rate_denominator': line.exchangeRateDenominator,
          'amount_usd': amountUsd,
        });

        await _applyBalanceDelta(
          txn,
          accountId: line.fromAccountId,
          localDelta: -line.amount,
          usdDelta: -amountUsd,
          lineCurrency: line.currency,
        );
        await _applyBalanceDelta(
          txn,
          accountId: line.toAccountId,
          localDelta: line.amount,
          usdDelta: amountUsd,
          lineCurrency: line.currency,
        );

        lineNumber++;
      }

      // 5. Audit log.
      await txn.insert(DbSchema.tableAuditLog, <String, Object?>{
        'entity_type': 'movement',
        'entity_id': movementId,
        'action': 'created',
        'old_values': null,
        'new_values': jsonEncode(<String, Object?>{
          'sequential_number': sequentialNumber,
          'date': date,
          'time': time,
          'lines': lines
              .map((MovementLineInput l) => <String, Object?>{
                    'from_account_id': l.fromAccountId,
                    'to_account_id': l.toAccountId,
                    'amount': l.amount,
                    'currency': l.currency,
                  })
              .toList(),
        }),
        'changed_by': createdBy,
        'changed_at': now,
      });

      result = Movement(
        id: movementId,
        uuid: movementUuid,
        sequentialNumber: sequentialNumber,
        date: date,
        time: time,
        status: 'posted',
        note: note,
        noteLevel: noteLevel,
        isOpeningBalance: isOpeningBalance,
        fiscalYearId: fiscalYearId,
        createdBy: createdBy,
        createdAt: now,
        postedAt: now,
      );
    });

    return result;
  }

  /// Creates a reversing movement for [originalMovementId]: a new posted
  /// movement whose lines mirror the original with from/to swapped, and
  /// flips the original's status to 'reversed'. The original row's other
  /// columns are never touched — only `status` changes — per "movements
  /// are immutable after posting."
  Future<Movement> reverseMovement({
    required int originalMovementId,
    String? note,
    String? createdBy,
  }) async {
    final Database db = await _dbHelper.database;
    late Movement result;

    await db.transaction((Transaction txn) async {
      final originalRows = await txn.query(
        DbSchema.tableMovements,
        where: 'id = ?',
        whereArgs: [originalMovementId],
      );
      if (originalRows.isEmpty) {
        throw StateError('Movement $originalMovementId does not exist');
      }
      final Map<String, Object?> original = originalRows.first;
      if (original['status'] != 'posted') {
        throw StateError(
          'Only posted movements can be reversed (current status: ${original['status']})',
        );
      }
      if (original['is_locked'] == 1) {
        throw StateError('Movement $originalMovementId is locked and cannot be reversed');
      }

      final lineRows = await txn.query(
        DbSchema.tableMovementLines,
        where: 'movement_id = ?',
        whereArgs: [originalMovementId],
        orderBy: 'line_number ASC',
      );

      final seqRows = await txn.rawQuery(
        'SELECT COALESCE(MAX(sequential_number), 0) + 1 AS next_seq '
        'FROM ${DbSchema.tableMovements}',
      );
      final int sequentialNumber = seqRows.first['next_seq']! as int;

      final String now = DateTime.now().toIso8601String();
      final String movementUuid = _uuid.v4();
      final String reversalNote = note ?? 'Reversal of #${original['sequential_number']}';
      final int reversalId = await txn.insert(DbSchema.tableMovements, <String, Object?>{
        'uuid': movementUuid,
        'sequential_number': sequentialNumber,
        'date': now.substring(0, 10),
        'time': now.substring(11, 16),
        'status': 'posted',
        'note': reversalNote,
        'note_level': 'important',
        'is_opening_balance': 0,
        'is_locked': 0,
        'fiscal_year_id': original['fiscal_year_id'],
        'reversal_of_movement_id': originalMovementId,
        'created_by': createdBy,
        'created_at': now,
        'posted_at': now,
      });

      for (final Map<String, Object?> line in lineRows) {
        final int amount = line['amount']! as int;
        final String currency = line['currency']! as String;
        final int rateNum = line['exchange_rate_numerator']! as int;
        final int rateDenom = line['exchange_rate_denominator']! as int;
        final int amountUsd = line['amount_usd']! as int;
        // Swapped: the reversal's from/to are the original's to/from.
        final int fromId = line['to_account_id']! as int;
        final int toId = line['from_account_id']! as int;

        await txn.insert(DbSchema.tableMovementLines, <String, Object?>{
          'movement_id': reversalId,
          'line_number': line['line_number'],
          'from_account_id': fromId,
          'to_account_id': toId,
          'amount': amount,
          'currency': currency,
          'exchange_rate_numerator': rateNum,
          'exchange_rate_denominator': rateDenom,
          'amount_usd': amountUsd,
        });

        await _applyBalanceDelta(
          txn,
          accountId: fromId,
          localDelta: -amount,
          usdDelta: -amountUsd,
          lineCurrency: currency,
        );
        await _applyBalanceDelta(
          txn,
          accountId: toId,
          localDelta: amount,
          usdDelta: amountUsd,
          lineCurrency: currency,
        );
      }

      await txn.update(
        DbSchema.tableMovements,
        <String, Object?>{'status': 'reversed'},
        where: 'id = ?',
        whereArgs: [originalMovementId],
      );

      await txn.insert(DbSchema.tableAuditLog, <String, Object?>{
        'entity_type': 'movement',
        'entity_id': originalMovementId,
        'action': 'status_changed',
        'old_values': jsonEncode(<String, Object?>{'status': 'posted'}),
        'new_values': jsonEncode(<String, Object?>{
          'status': 'reversed',
          'reversed_by_movement_id': reversalId,
        }),
        'changed_by': createdBy,
        'changed_at': now,
      });

      result = Movement(
        id: reversalId,
        uuid: movementUuid,
        sequentialNumber: sequentialNumber,
        date: now.substring(0, 10),
        time: now.substring(11, 16),
        status: 'posted',
        note: reversalNote,
        noteLevel: 'important',
        fiscalYearId: original['fiscal_year_id'] as int?,
        reversalOfMovementId: originalMovementId,
        createdBy: createdBy,
        createdAt: now,
        postedAt: now,
      );
    });

    return result;
  }

  /// Voids a draft movement (soft delete).
  ///
  /// Design note / disclosed assumption: per the Founder's lifecycle
  /// decision (Draft -> Posted -> Reversed -> Void, no is_reversed flag),
  /// it's not stated whether Void is reachable from Posted/Reversed too.
  /// This implementation only allows Void from Draft — posted movements
  /// can only be corrected via [reverseMovement] — since that's the only
  /// reading consistent with "correction is performed only through
  /// reversing movements." If the Founder wants Void reachable from
  /// Reversed as well (e.g. to hide a fully-cancelled pair from history),
  /// that's a one-line change to the status check below.
  Future<void> voidDraftMovement(int movementId) async {
    final Database db = await _dbHelper.database;
    await db.transaction((Transaction txn) async {
      final rows = await txn.query(DbSchema.tableMovements, where: 'id = ?', whereArgs: [movementId]);
      if (rows.isEmpty) {
        throw StateError('Movement $movementId does not exist');
      }
      if (rows.first['status'] != 'draft') {
        throw StateError('Only draft movements can be voided directly (use reverseMovement for posted ones)');
      }
      final String now = DateTime.now().toIso8601String();
      await txn.update(
        DbSchema.tableMovements,
        <String, Object?>{'status': 'void'},
        where: 'id = ?',
        whereArgs: [movementId],
      );
      await txn.insert(DbSchema.tableAuditLog, <String, Object?>{
        'entity_type': 'movement',
        'entity_id': movementId,
        'action': 'status_changed',
        'old_values': jsonEncode(<String, Object?>{'status': 'draft'}),
        'new_values': jsonEncode(<String, Object?>{'status': 'void'}),
        'changed_by': null,
        'changed_at': now,
      });
    });
  }

  /// Applies a balance delta to one account.
  ///
  /// Design note: `running_balance` (local currency) is only updated
  /// when the line's currency matches the account's own currency — a
  /// USD-denominated account touched by a EUR-denominated line (e.g. the
  /// "Currency Exchange Clearing" system account during a currency
  /// exchange) has its `running_balance_usd` updated but its
  /// `running_balance` left alone, since the line simply isn't
  /// denominated in that account's currency. This means local balances
  /// stay meaningful for ordinary same-currency accounts, while
  /// virtual/clearing accounts are read via running_balance_usd only.
  /// This is the trickiest part of the whole model — Phase 2's
  /// CurrencyExchangeService should carry an explicit unit test for the
  /// Blueprint's own 5:30 PM three-line exchange example against this
  /// logic before it's trusted with real data.
  Future<void> _applyBalanceDelta(
    Transaction txn, {
    required int accountId,
    required int localDelta,
    required int usdDelta,
    required String lineCurrency,
  }) async {
    final rows = await txn.query(
      DbSchema.tableAccounts,
      columns: ['currency'],
      where: 'id = ?',
      whereArgs: [accountId],
    );
    final String accountCurrency = rows.first['currency']! as String;
    final bool sameCurrency = accountCurrency == lineCurrency;

    await txn.rawUpdate(
      'UPDATE ${DbSchema.tableAccounts} '
      'SET running_balance = running_balance + ?, '
      '    running_balance_usd = running_balance_usd + ? '
      'WHERE id = ?',
      [sameCurrency ? localDelta : 0, usdDelta, accountId],
    );
  }

  Future<Movement?> findBySequentialNumber(int sequentialNumber) async {
    final Database db = await _dbHelper.database;
    final rows = await db.query(
      DbSchema.tableMovements,
      where: 'sequential_number = ?',
      whereArgs: [sequentialNumber],
    );
    if (rows.isEmpty) return null;
    return Movement.fromMap(rows.first);
  }

  /// Numeric queries match a sequential number exactly; anything else is
  /// matched against note text.
  Future<List<Movement>> search(String query, {int limit = 50}) async {
    final Database db = await _dbHelper.database;
    final int? asNumber = int.tryParse(query);
    if (asNumber != null) {
      final rows = await db.query(
        DbSchema.tableMovements,
        where: 'sequential_number = ?',
        whereArgs: [asNumber],
      );
      return rows.map(Movement.fromMap).toList();
    }
    final rows = await db.query(
      DbSchema.tableMovements,
      where: 'note LIKE ?',
      whereArgs: ['%$query%'],
      orderBy: 'date DESC',
      limit: limit,
    );
    return rows.map(Movement.fromMap).toList();
  }

  /// Paginated (limit/offset) ledger for one account — every posted line
  /// where the account appears as either side.
  Future<List<Map<String, Object?>>> getAccountLedger(
    int accountId, {
    String? dateFrom,
    String? dateTo,
    int limit = 50,
    int offset = 0,
  }) async {
    final Database db = await _dbHelper.database;
    final List<String> whereClauses = <String>[
      '(ml.from_account_id = ? OR ml.to_account_id = ?)',
      "m.status = 'posted'",
    ];
    final List<Object?> whereArgs = <Object?>[accountId, accountId];
    if (dateFrom != null) {
      whereClauses.add('m.date >= ?');
      whereArgs.add(dateFrom);
    }
    if (dateTo != null) {
      whereClauses.add('m.date <= ?');
      whereArgs.add(dateTo);
    }
    return db.rawQuery(
      '''
      SELECT m.id, m.sequential_number, m.date, m.time, m.note, m.note_level,
             ml.from_account_id, ml.to_account_id, ml.amount, ml.currency,
             ml.amount_usd
      FROM ${DbSchema.tableMovementLines} ml
      JOIN ${DbSchema.tableMovements} m ON m.id = ml.movement_id
      WHERE ${whereClauses.join(' AND ')}
      ORDER BY m.date DESC, m.sequential_number DESC
      LIMIT ? OFFSET ?
      ''',
      [...whereArgs, limit, offset],
    );
  }
}
