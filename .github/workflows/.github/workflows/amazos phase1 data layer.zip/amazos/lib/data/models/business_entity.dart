class BusinessEntity {
  const BusinessEntity({
    this.id,
    required this.uuid,
    required this.name,
    required this.type,
    this.phone,
    this.email,
    this.status = 'active',
    required this.createdAt,
  });

  final int? id;
  final String uuid;
  final String name;

  /// 'customer' | 'supplier' | 'both'
  final String type;
  final String? phone;
  final String? email;

  /// 'active' | 'inactive'
  final String status;
  final String createdAt;

  Map<String, Object?> toMap() => <String, Object?>{
        if (id != null) 'id': id,
        'uuid': uuid,
        'name': name,
        'type': type,
        'phone': phone,
        'email': email,
        'status': status,
        'created_at': createdAt,
      };

  factory BusinessEntity.fromMap(Map<String, Object?> map) => BusinessEntity(
        id: map['id'] as int?,
        uuid: map['uuid']! as String,
        name: map['name']! as String,
        type: map['type']! as String,
        phone: map['phone'] as String?,
        email: map['email'] as String?,
        status: map['status']! as String,
        createdAt: map['created_at']! as String,
      );
}
