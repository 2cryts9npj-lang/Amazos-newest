class MovementLine {
  const MovementLine({
    this.id,
    required this.movementId,
    required this.lineNumber,
    required this.fromAccountId,
    required this.toAccountId,
    required this.amount,
    required this.currency,
    this.exchangeRateNumerator = 1,
    this.exchangeRateDenominator = 1,
    required this.amountUsd,
  });

  final int? id;
  final int movementId;
  final int lineNumber;
  final int fromAccountId;
  final int toAccountId;

  /// Smallest unit of [currency]. Always positive.
  final int amount;
  final String currency;
  final int exchangeRateNumerator;
  final int exchangeRateDenominator;

  /// USD cents, computed as amount * numerator / denominator (rounded)
  /// at the moment the line was posted, and stored — never recalculated.
  final int amountUsd;

  Map<String, Object?> toMap() => <String, Object?>{
        if (id != null) 'id': id,
        'movement_id': movementId,
        'line_number': lineNumber,
        'from_account_id': fromAccountId,
        'to_account_id': toAccountId,
        'amount': amount,
        'currency': currency,
        'exchange_rate_numerator': exchangeRateNumerator,
        'exchange_rate_denominator': exchangeRateDenominator,
        'amount_usd': amountUsd,
      };

  factory MovementLine.fromMap(Map<String, Object?> map) => MovementLine(
        id: map['id'] as int?,
        movementId: map['movement_id']! as int,
        lineNumber: map['line_number']! as int,
        fromAccountId: map['from_account_id']! as int,
        toAccountId: map['to_account_id']! as int,
        amount: map['amount']! as int,
        currency: map['currency']! as String,
        exchangeRateNumerator: map['exchange_rate_numerator']! as int,
        exchangeRateDenominator: map['exchange_rate_denominator']! as int,
        amountUsd: map['amount_usd']! as int,
      );
}

/// Input DTO for creating one line of a new movement — no id/amountUsd
/// yet, since those are assigned during posting.
class MovementLineInput {
  const MovementLineInput({
    required this.fromAccountId,
    required this.toAccountId,
    required this.amount,
    required this.currency,
    this.exchangeRateNumerator = 1,
    this.exchangeRateDenominator = 1,
  });

  final int fromAccountId;
  final int toAccountId;
  final int amount;
  final String currency;
  final int exchangeRateNumerator;
  final int exchangeRateDenominator;
}
