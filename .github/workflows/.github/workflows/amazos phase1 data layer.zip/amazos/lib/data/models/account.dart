class Account {
  const Account({
    this.id,
    required this.uuid,
    required this.name,
    required this.type,
    required this.currency,
    this.runningBalance = 0,
    this.runningBalanceUsd = 0,
    this.status = 'active',
    this.isSystem = false,
    this.businessEntityId,
    required this.createdAt,
  });

  final int? id;
  final String uuid;
  final String name;

  /// asset, liability, equity, income, expense, cash, bank, customer,
  /// supplier, inventory, loan, investment, virtual, system — free-form
  /// per the Blueprint ("Never hardcoded"), used only for report grouping.
  final String type;

  /// ISO 4217 currency code.
  final String currency;

  /// Smallest local-currency unit (e.g. cents). Only meaningful when a
  /// movement line's currency matches this account's own currency — see
  /// the note in movement_repository.dart on virtual/clearing accounts.
  final int runningBalance;

  /// USD cents. Always meaningful, updated on every movement line
  /// touching this account regardless of the line's currency.
  final int runningBalanceUsd;

  /// 'active' | 'archived' | 'locked'
  final String status;
  final bool isSystem;
  final int? businessEntityId;
  final String createdAt;

  Map<String, Object?> toMap() => <String, Object?>{
        if (id != null) 'id': id,
        'uuid': uuid,
        'name': name,
        'type': type,
        'currency': currency,
        'running_balance': runningBalance,
        'running_balance_usd': runningBalanceUsd,
        'status': status,
        'is_system': isSystem ? 1 : 0,
        'business_entity_id': businessEntityId,
        'created_at': createdAt,
      };

  factory Account.fromMap(Map<String, Object?> map) => Account(
        id: map['id'] as int?,
        uuid: map['uuid']! as String,
        name: map['name']! as String,
        type: map['type']! as String,
        currency: map['currency']! as String,
        runningBalance: map['running_balance']! as int,
        runningBalanceUsd: map['running_balance_usd']! as int,
        status: map['status']! as String,
        isSystem: (map['is_system']! as int) == 1,
        businessEntityId: map['business_entity_id'] as int?,
        createdAt: map['created_at']! as String,
      );
}
