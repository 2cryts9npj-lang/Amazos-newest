import 'package:uuid/uuid.dart';

import '../../core/database/database_helper.dart';
import '../../core/database/db_schema.dart';
import '../models/business_entity.dart';

class BusinessEntityRepository {
  BusinessEntityRepository(this._dbHelper);

  final DatabaseHelper _dbHelper;
  static const Uuid _uuid = Uuid();

  Future<BusinessEntity> create({
    required String name,
    required String type,
    String? phone,
    String? email,
  }) async {
    final db = await _dbHelper.database;
    final String now = DateTime.now().toIso8601String();
    final String entityUuid = _uuid.v4();
    final int id = await db.insert(DbSchema.tableBusinessEntities, <String, Object?>{
      'uuid': entityUuid,
      'name': name,
      'type': type,
      'phone': phone,
      'email': email,
      'status': 'active',
      'created_at': now,
    });
    return BusinessEntity(
      id: id,
      uuid: entityUuid,
      name: name,
      type: type,
      phone: phone,
      email: email,
      createdAt: now,
    );
  }

  Future<List<BusinessEntity>> search(String query) async {
    final db = await _dbHelper.database;
    final rows = await db.query(
      DbSchema.tableBusinessEntities,
      where: 'name LIKE ? AND status = ?',
      whereArgs: ['%$query%', 'active'],
      orderBy: 'name ASC',
    );
    return rows.map(BusinessEntity.fromMap).toList();
  }

  Future<List<BusinessEntity>> getAll({String status = 'active'}) async {
    final db = await _dbHelper.database;
    final rows = await db.query(
      DbSchema.tableBusinessEntities,
      where: 'status = ?',
      whereArgs: [status],
      orderBy: 'name ASC',
    );
    return rows.map(BusinessEntity.fromMap).toList();
  }
}
