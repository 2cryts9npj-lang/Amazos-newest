/// One append-only audit record. Written by repositories, never by the
/// UI directly, and never updated or deleted after insertion.
class AuditLogEntry {
  const AuditLogEntry({
    this.id,
    required this.entityType,
    required this.entityId,
    required this.action,
    this.oldValues,
    this.newValues,
    this.changedBy,
    required this.changedAt,
  });

  final int? id;
  final String entityType;
  final int entityId;

  /// e.g. 'created', 'status_changed', 'deleted'
  final String action;

  /// JSON-encoded snapshot, or null on creation.
  final String? oldValues;

  /// JSON-encoded snapshot.
  final String? newValues;
  final String? changedBy;
  final String changedAt;

  Map<String, Object?> toMap() => <String, Object?>{
        if (id != null) 'id': id,
        'entity_type': entityType,
        'entity_id': entityId,
        'action': action,
        'old_values': oldValues,
        'new_values': newValues,
        'changed_by': changedBy,
        'changed_at': changedAt,
      };

  factory AuditLogEntry.fromMap(Map<String, Object?> map) => AuditLogEntry(
        id: map['id'] as int?,
        entityType: map['entity_type']! as String,
        entityId: map['entity_id']! as int,
        action: map['action']! as String,
        oldValues: map['old_values'] as String?,
        newValues: map['new_values'] as String?,
        changedBy: map['changed_by'] as String?,
        changedAt: map['changed_at']! as String,
      );
}
