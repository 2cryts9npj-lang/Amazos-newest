import '../../core/database/database_helper.dart';
import '../../core/database/db_schema.dart';
import '../models/audit_log_entry.dart';

/// Read-only on purpose: audit_log rows are written only by the other
/// repositories, inline with the operation they're logging, inside the
/// same db transaction. Nothing here inserts, updates, or deletes.
class AuditRepository {
  AuditRepository(this._dbHelper);

  final DatabaseHelper _dbHelper;

  Future<List<AuditLogEntry>> getHistoryFor(String entityType, int entityId) async {
    final db = await _dbHelper.database;
    final rows = await db.query(
      DbSchema.tableAuditLog,
      where: 'entity_type = ? AND entity_id = ?',
      whereArgs: [entityType, entityId],
      orderBy: 'changed_at ASC',
    );
    return rows.map(AuditLogEntry.fromMap).toList();
  }
}
