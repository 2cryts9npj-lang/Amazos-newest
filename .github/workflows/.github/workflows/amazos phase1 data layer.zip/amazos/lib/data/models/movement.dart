/// The header of a cash movement. Contains no monetary amounts — those
/// live on its [MovementLine]s. A movement owns one or more lines
/// (multi-line, per Founder decision on multi-currency).
///
/// Named `Movement` rather than the Blueprint's `Transaction` to avoid
/// colliding with sqflite's own `Transaction` type — see db_schema.dart.
class Movement {
  const Movement({
    this.id,
    required this.uuid,
    required this.sequentialNumber,
    required this.date,
    required this.time,
    this.status = 'draft',
    this.note,
    this.noteLevel,
    this.isOpeningBalance = false,
    this.isLocked = false,
    this.fiscalYearId,
    this.reversalOfMovementId,
    this.createdBy,
    required this.createdAt,
    this.postedAt,
  });

  final int? id;
  final String uuid;

  /// Permanent, human-facing identity (e.g. "#10345"). Never reused.
  final int sequentialNumber;

  /// ISO date, yyyy-MM-dd.
  final String date;

  /// HH:MM (24h).
  final String time;

  /// 'draft' | 'posted' | 'reversed' | 'void'
  final String status;
  final String? note;

  /// 'info' | 'reminder' | 'important' | 'warning' | 'critical'
  final String? noteLevel;
  final bool isOpeningBalance;
  final bool isLocked;
  final int? fiscalYearId;

  /// Set only on a reversal movement, pointing at the movement it
  /// reverses. A disclosed addition to the Blueprint's original "reference
  /// via a note" idea — see db_schema.dart.
  final int? reversalOfMovementId;
  final String? createdBy;
  final String createdAt;
  final String? postedAt;

  Map<String, Object?> toMap() => <String, Object?>{
        if (id != null) 'id': id,
        'uuid': uuid,
        'sequential_number': sequentialNumber,
        'date': date,
        'time': time,
        'status': status,
        'note': note,
        'note_level': noteLevel,
        'is_opening_balance': isOpeningBalance ? 1 : 0,
        'is_locked': isLocked ? 1 : 0,
        'fiscal_year_id': fiscalYearId,
        'reversal_of_movement_id': reversalOfMovementId,
        'created_by': createdBy,
        'created_at': createdAt,
        'posted_at': postedAt,
      };

  factory Movement.fromMap(Map<String, Object?> map) => Movement(
        id: map['id'] as int?,
        uuid: map['uuid']! as String,
        sequentialNumber: map['sequential_number']! as int,
        date: map['date']! as String,
        time: map['time']! as String,
        status: map['status']! as String,
        note: map['note'] as String?,
        noteLevel: map['note_level'] as String?,
        isOpeningBalance: (map['is_opening_balance']! as int) == 1,
        isLocked: (map['is_locked']! as int) == 1,
        fiscalYearId: map['fiscal_year_id'] as int?,
        reversalOfMovementId: map['reversal_of_movement_id'] as int?,
        createdBy: map['created_by'] as String?,
        createdAt: map['created_at']! as String,
        postedAt: map['posted_at'] as String?,
      );
}
