import 'dart:convert';

import 'package:uuid/uuid.dart';

import '../../core/database/database_helper.dart';
import '../../core/database/db_schema.dart';
import '../models/note.dart';

class NoteRepository {
  NoteRepository(this._dbHelper);

  final DatabaseHelper _dbHelper;
  static const Uuid _uuid = Uuid();

  /// Highest severity first — drives which single marker shows on a list
  /// row when an entity has notes at multiple levels.
  static const List<String> severityOrder = <String>[
    'critical',
    'warning',
    'important',
    'reminder',
    'info',
  ];

  Future<Note> addNote({
    required String entityType,
    required int entityId,
    required String level,
    required String body,
    bool isPrivate = false,
    String? reminderDate,
    String? createdBy,
  }) async {
    if (!severityOrder.contains(level)) {
      throw ArgumentError('Unknown note level: $level');
    }
    final db = await _dbHelper.database;
    final String now = DateTime.now().toIso8601String();
    final String noteUuid = _uuid.v4();
    final int id = await db.insert(DbSchema.tableNotes, <String, Object?>{
      'uuid': noteUuid,
      'entity_type': entityType,
      'entity_id': entityId,
      'level': level,
      'body': body,
      'is_private': isPrivate ? 1 : 0,
      'reminder_date': reminderDate,
      'created_by': createdBy,
      'created_at': now,
      'is_deleted': 0,
    });
    await db.insert(DbSchema.tableAuditLog, <String, Object?>{
      'entity_type': 'note',
      'entity_id': id,
      'action': 'created',
      'old_values': null,
      'new_values': jsonEncode(<String, Object?>{
        'entity_type': entityType,
        'entity_id': entityId,
        'level': level,
      }),
      'changed_by': createdBy,
      'changed_at': now,
    });
    return Note(
      id: id,
      uuid: noteUuid,
      entityType: entityType,
      entityId: entityId,
      level: level,
      body: body,
      isPrivate: isPrivate,
      reminderDate: reminderDate,
      createdBy: createdBy,
      createdAt: now,
    );
  }

  /// Chronological notes for one entity — this doubles as that entity's
  /// timeline. "Everything has a Timeline" is implemented as this query,
  /// not as a separately maintained table.
  Future<List<Note>> getTimelineFor(
    String entityType,
    int entityId, {
    bool includePrivate = true,
  }) async {
    final db = await _dbHelper.database;
    final String where = includePrivate
        ? 'entity_type = ? AND entity_id = ? AND is_deleted = 0'
        : 'entity_type = ? AND entity_id = ? AND is_deleted = 0 AND is_private = 0';
    final rows = await db.query(
      DbSchema.tableNotes,
      where: where,
      whereArgs: [entityType, entityId],
      orderBy: 'created_at ASC',
    );
    return rows.map(Note.fromMap).toList();
  }

  /// The single level that should drive an entity's colored marker badge
  /// — highest severity wins, per the "interrupt, don't just log" rule.
  Future<String?> highestSeverityFor(String entityType, int entityId) async {
    final List<Note> notes = await getTimelineFor(entityType, entityId);
    if (notes.isEmpty) return null;
    for (final String level in severityOrder) {
      if (notes.any((Note n) => n.level == level)) return level;
    }
    return null;
  }

  /// Notes with an upcoming reminder date, across all entity types — the
  /// query behind a future "today's reminders" dashboard view.
  Future<List<Note>> getUpcomingReminders({String? onOrBeforeDate}) async {
    final db = await _dbHelper.database;
    final String where = onOrBeforeDate != null
        ? 'reminder_date IS NOT NULL AND reminder_date <= ? AND is_deleted = 0'
        : 'reminder_date IS NOT NULL AND is_deleted = 0';
    final List<Object?> whereArgs = onOrBeforeDate != null ? [onOrBeforeDate] : [];
    final rows = await db.query(
      DbSchema.tableNotes,
      where: where,
      whereArgs: whereArgs,
      orderBy: 'reminder_date ASC',
    );
    return rows.map(Note.fromMap).toList();
  }
}
