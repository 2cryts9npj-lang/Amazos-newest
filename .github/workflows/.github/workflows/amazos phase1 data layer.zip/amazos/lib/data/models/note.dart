/// A note attachable to any entity in the system via [entityType] +
/// [entityId] — a movement, an account, a business entity, or any future
/// module. This is the data behind both the colored severity marker and
/// the per-entity timeline; both are derived queries, not separate
/// stored structures.
class Note {
  const Note({
    this.id,
    required this.uuid,
    required this.entityType,
    required this.entityId,
    required this.level,
    required this.body,
    this.isPrivate = false,
    this.reminderDate,
    this.createdBy,
    required this.createdAt,
    this.isDeleted = false,
  });

  final int? id;
  final String uuid;

  /// e.g. 'movement', 'account', 'business_entity' — free-form, matched
  /// against whatever table the note is attached to.
  final String entityType;
  final int entityId;

  /// 'info' | 'reminder' | 'important' | 'warning' | 'critical'
  final String level;
  final String body;

  /// If true, only the note's owner sees it (e.g. an employee vs. owner
  /// visibility split described in the Founder's original notes spec).
  final bool isPrivate;

  /// If set, this note is also a reminder that should surface on a
  /// dashboard/daily view — not just sit on the entity's own page.
  final String? reminderDate;
  final String? createdBy;
  final String createdAt;
  final bool isDeleted;

  Map<String, Object?> toMap() => <String, Object?>{
        if (id != null) 'id': id,
        'uuid': uuid,
        'entity_type': entityType,
        'entity_id': entityId,
        'level': level,
        'body': body,
        'is_private': isPrivate ? 1 : 0,
        'reminder_date': reminderDate,
        'created_by': createdBy,
        'created_at': createdAt,
        'is_deleted': isDeleted ? 1 : 0,
      };

  factory Note.fromMap(Map<String, Object?> map) => Note(
        id: map['id'] as int?,
        uuid: map['uuid']! as String,
        entityType: map['entity_type']! as String,
        entityId: map['entity_id']! as int,
        level: map['level']! as String,
        body: map['body']! as String,
        isPrivate: (map['is_private']! as int) == 1,
        reminderDate: map['reminder_date'] as String?,
        createdBy: map['created_by'] as String?,
        createdAt: map['created_at']! as String,
        isDeleted: (map['is_deleted']! as int) == 1,
      );
}
