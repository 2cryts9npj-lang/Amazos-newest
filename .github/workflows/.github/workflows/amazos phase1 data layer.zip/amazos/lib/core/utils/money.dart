/// Integer-only money math.
///
/// JUNTA Constitution Rule 4: "Integers for money." Rule 5: "Exchange
/// rates are explicit." Nothing in this file ever touches a double for a
/// monetary amount.
class Money {
  Money._();

  /// Converts an amount in a currency's smallest unit (e.g. cents, fils)
  /// to USD cents, using an explicit rate expressed as a
  /// numerator/denominator pair (e.g. 110/100 for a rate of 1.10), per
  /// the Blueprint's "stored as a numerator and denominator... to avoid
  /// floating-point errors" rule.
  ///
  /// Rounds half up on ties.
  static int toUsdCents({
    required int amountMinorUnits,
    required int rateNumerator,
    required int rateDenominator,
  }) {
    if (rateDenominator == 0) {
      throw ArgumentError('Exchange rate denominator cannot be zero');
    }
    final int numerator = amountMinorUnits * rateNumerator;
    final int half = rateDenominator ~/ 2;
    return (numerator + half) ~/ rateDenominator;
  }

  /// The weighted-average cost rate for a currency holding, expressed in
  /// the same numerator/denominator shape as a movement-line rate.
  ///
  /// This is derived directly from an account's own two running balances
  /// (running_balance in local currency, running_balance_usd) rather than
  /// a separate average-cost table — per the Blueprint, an inflow updates
  /// both balances proportionally, so at any moment their ratio already
  /// *is* the average cost.
  ///
  /// Returns null if the account currently holds zero units — there is
  /// no average cost to relieve at.
  static ({int numerator, int denominator})? averageCostRate({
    required int runningBalanceLocal,
    required int runningBalanceUsd,
  }) {
    if (runningBalanceLocal == 0) return null;
    return (numerator: runningBalanceUsd, denominator: runningBalanceLocal);
  }
}
