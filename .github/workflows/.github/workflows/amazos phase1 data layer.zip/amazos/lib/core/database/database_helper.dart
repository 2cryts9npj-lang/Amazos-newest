import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:uuid/uuid.dart';

import 'db_schema.dart';

/// Owns the single SQLite connection and the migration framework.
///
/// Migration rule (JUNTA Constitution, Rule 6 + "Migration Strategy" in
/// the Blueprint): migrations are additive only. Each future version
/// bump gets its own `if (oldVersion < N)` block inside [_onUpgrade].
/// Nothing above an existing block is ever rewritten or removed.
class DatabaseHelper {
  DatabaseHelper._internal();

  static final DatabaseHelper instance = DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    _database ??= await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final String dbPath = await getDatabasesPath();
    final String path = join(dbPath, 'amazos.db');
    return openDatabase(
      path,
      version: DbSchema.schemaVersion,
      onConfigure: (Database db) async {
        // sqflite has foreign keys OFF by default — the constitution's
        // referential rules (from/to account must exist, etc.) depend on
        // this being on.
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    final Batch batch = db.batch();
    batch.execute(DbSchema.createBusinessEntities);
    batch.execute(DbSchema.createFiscalYears);
    batch.execute(DbSchema.createAccounts);
    batch.execute(DbSchema.createMovements);
    batch.execute(DbSchema.createMovementLines);
    batch.execute(DbSchema.createNotes);
    batch.execute(DbSchema.createAuditLog);
    for (final String stmt in DbSchema.createIndexes) {
      batch.execute(stmt);
    }
    await batch.commit(noResult: true);

    await _seedSystemAccounts(db);
  }

  /// System accounts required by the Blueprint's currency and
  /// opening-balance workflow. `is_system = 1` means the future UI must
  /// never allow renaming or deleting these.
  ///
  /// "Currency Exchange Clearing" and "Cash Over/Short" are a disclosed
  /// addition: the Blueprint's own Section 2 workflow narrative (5:30 PM
  /// exchange, 6:00 PM closing) uses both by name but only formally
  /// listed "Opening Balance Equity" and "Realized Currency Gain/Loss" as
  /// system accounts. Seeding all four now avoids the UI later having to
  /// silently auto-create an account mid-transaction.
  Future<void> _seedSystemAccounts(Database db) async {
    const Uuid uuid = Uuid();
    final String now = DateTime.now().toIso8601String();
    final List<Map<String, String>> systemAccounts = <Map<String, String>>[
      <String, String>{
        'name': 'Opening Balance Equity',
        'type': 'equity',
        'currency': 'USD',
      },
      <String, String>{
        'name': 'Realized Currency Gain/Loss',
        'type': 'equity',
        'currency': 'USD',
      },
      <String, String>{
        'name': 'Currency Exchange Clearing',
        'type': 'virtual',
        'currency': 'USD',
      },
      <String, String>{
        'name': 'Cash Over/Short',
        'type': 'expense',
        'currency': 'USD',
      },
    ];

    for (final Map<String, String> acc in systemAccounts) {
      await db.insert(DbSchema.tableAccounts, <String, Object?>{
        'uuid': uuid.v4(),
        'name': acc['name'],
        'type': acc['type'],
        'currency': acc['currency'],
        'running_balance': 0,
        'running_balance_usd': 0,
        'status': 'active',
        'is_system': 1,
        'created_at': now,
      });
    }
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    // Version 1 -> 2 migrations will be appended here as additive blocks,
    // e.g.:
    // if (oldVersion < 2) {
    //   await db.execute('ALTER TABLE accounts ADD COLUMN parent_id INTEGER');
    // }
  }

  /// Test/dev-only: closes and forgets the cached connection so a fresh
  /// one is opened next time [database] is accessed. Not used by any
  /// production code path.
  Future<void> resetForTesting() async {
    final Database? db = _database;
    if (db != null) {
      await db.close();
      _database = null;
    }
  }
}
