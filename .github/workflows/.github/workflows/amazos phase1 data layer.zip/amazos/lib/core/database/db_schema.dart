/// Amazos Database Schema — Version 1
///
/// Cash Movement Operating System — Data Layer.
///
/// Table and column names are centralized here as the single source of
/// truth so repositories never hardcode raw strings. Nothing in this file
/// executes anything; it only describes structure.
///
/// Naming note: the JUNTA Blueprint calls the movement header/line tables
/// "transactions" / "transaction_lines". They're named `movements` /
/// `movement_lines` here instead, purely so the Dart model classes can be
/// called `Movement` / `MovementLine` without colliding with sqflite's own
/// `Transaction` type (used for db.transaction() callbacks). No business
/// meaning changed — flagging it since renaming a spec's own vocabulary is
/// exactly the kind of thing that should be disclosed, not silently done.
library db_schema;

class DbSchema {
  DbSchema._();

  static const int schemaVersion = 1;

  // ---------------------------------------------------------------------
  // Table names
  // ---------------------------------------------------------------------
  static const String tableBusinessEntities = 'business_entities';
  static const String tableFiscalYears = 'fiscal_years';
  static const String tableAccounts = 'accounts';
  static const String tableMovements = 'movements';
  static const String tableMovementLines = 'movement_lines';
  static const String tableNotes = 'notes';
  static const String tableAuditLog = 'audit_log';

  // ---------------------------------------------------------------------
  // CREATE TABLE statements (Version 1)
  // ---------------------------------------------------------------------

  static const String createBusinessEntities = '''
    CREATE TABLE $tableBusinessEntities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uuid TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      type TEXT NOT NULL CHECK (type IN ('customer','supplier','both')),
      phone TEXT,
      email TEXT,
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
      created_at TEXT NOT NULL
    )
  ''';

  static const String createFiscalYears = '''
    CREATE TABLE $tableFiscalYears (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      is_closed INTEGER NOT NULL DEFAULT 0
    )
  ''';

  static const String createAccounts = '''
    CREATE TABLE $tableAccounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uuid TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      type TEXT NOT NULL,
      currency TEXT NOT NULL,
      running_balance INTEGER NOT NULL DEFAULT 0,
      running_balance_usd INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived','locked')),
      is_system INTEGER NOT NULL DEFAULT 0,
      business_entity_id INTEGER REFERENCES $tableBusinessEntities(id),
      created_at TEXT NOT NULL
    )
  ''';

  /// The movement header. Contains NO monetary amounts — those live in
  /// movement_lines. A header may own one or more lines (multi-line, per
  /// Founder decision on multi-currency).
  static const String createMovements = '''
    CREATE TABLE $tableMovements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uuid TEXT NOT NULL UNIQUE,
      sequential_number INTEGER NOT NULL UNIQUE,
      date TEXT NOT NULL,
      time TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','posted','reversed','void')),
      note TEXT,
      note_level TEXT CHECK (note_level IN ('info','reminder','important','warning','critical')),
      is_opening_balance INTEGER NOT NULL DEFAULT 0,
      is_locked INTEGER NOT NULL DEFAULT 0,
      fiscal_year_id INTEGER REFERENCES $tableFiscalYears(id),
      reversal_of_movement_id INTEGER REFERENCES $tableMovements(id),
      created_by TEXT,
      created_at TEXT NOT NULL,
      posted_at TEXT
    )
  ''';

  /// reversal_of_movement_id is a disclosed addition beyond the blueprint
  /// text (which said reversals "reference the original via a note").
  /// A real FK is more consistent with the constitution's own
  /// traceability rule than parsing note text to find related movements.

  static const String createMovementLines = '''
    CREATE TABLE $tableMovementLines (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      movement_id INTEGER NOT NULL REFERENCES $tableMovements(id),
      line_number INTEGER NOT NULL,
      from_account_id INTEGER NOT NULL REFERENCES $tableAccounts(id),
      to_account_id INTEGER NOT NULL REFERENCES $tableAccounts(id),
      amount INTEGER NOT NULL,
      currency TEXT NOT NULL,
      exchange_rate_numerator INTEGER NOT NULL DEFAULT 1,
      exchange_rate_denominator INTEGER NOT NULL DEFAULT 1,
      amount_usd INTEGER NOT NULL
    )
  ''';

  /// Universal notes: entity_type + entity_id lets ANY table's rows carry
  /// notes (movement, account, business_entity, and any future module)
  /// without a notes-per-table join table for each one.
  static const String createNotes = '''
    CREATE TABLE $tableNotes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uuid TEXT NOT NULL UNIQUE,
      entity_type TEXT NOT NULL,
      entity_id INTEGER NOT NULL,
      level TEXT NOT NULL CHECK (level IN ('info','reminder','important','warning','critical')),
      body TEXT NOT NULL,
      is_private INTEGER NOT NULL DEFAULT 0,
      reminder_date TEXT,
      created_by TEXT,
      created_at TEXT NOT NULL,
      is_deleted INTEGER NOT NULL DEFAULT 0
    )
  ''';

  static const String createAuditLog = '''
    CREATE TABLE $tableAuditLog (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      entity_type TEXT NOT NULL,
      entity_id INTEGER NOT NULL,
      action TEXT NOT NULL,
      old_values TEXT,
      new_values TEXT,
      changed_by TEXT,
      changed_at TEXT NOT NULL
    )
  ''';

  // ---------------------------------------------------------------------
  // Indexes (Version 1) — required by the constitution, not optional.
  // ---------------------------------------------------------------------
  static const List<String> createIndexes = [
    'CREATE INDEX idx_business_entities_name ON $tableBusinessEntities(name)',
    'CREATE INDEX idx_fiscal_years_start ON $tableFiscalYears(start_date)',
    'CREATE INDEX idx_accounts_type ON $tableAccounts(type)',
    'CREATE INDEX idx_accounts_status ON $tableAccounts(status)',
    'CREATE INDEX idx_accounts_currency ON $tableAccounts(currency)',
    'CREATE INDEX idx_accounts_business_entity ON $tableAccounts(business_entity_id)',
    'CREATE INDEX idx_movements_date ON $tableMovements(date)',
    'CREATE INDEX idx_movements_fiscal_year ON $tableMovements(fiscal_year_id)',
    'CREATE INDEX idx_movements_status ON $tableMovements(status)',
    'CREATE INDEX idx_movements_note_level ON $tableMovements(note_level)',
    'CREATE INDEX idx_movements_reversal_of ON $tableMovements(reversal_of_movement_id)',
    'CREATE INDEX idx_lines_movement ON $tableMovementLines(movement_id)',
    'CREATE INDEX idx_lines_from_account ON $tableMovementLines(from_account_id)',
    'CREATE INDEX idx_lines_to_account ON $tableMovementLines(to_account_id)',
    'CREATE INDEX idx_notes_entity ON $tableNotes(entity_type, entity_id)',
    'CREATE INDEX idx_notes_level ON $tableNotes(level)',
    'CREATE INDEX idx_notes_reminder_date ON $tableNotes(reminder_date)',
    'CREATE INDEX idx_audit_entity ON $tableAuditLog(entity_type, entity_id)',
    'CREATE INDEX idx_audit_changed_at ON $tableAuditLog(changed_at)',
  ];
  // Note: sequential_number's uniqueness is already enforced by the
  // column-level UNIQUE constraint in createMovements, so no separate
  // unique index is declared here (SQLite creates one automatically).
}
