import 'package:flutter/material.dart';

import 'core/database/database_helper.dart';
import 'data/repositories/account_repository.dart';

/// Phase 1 entry point.
///
/// This does NOT implement the Cash Register, reports, or any real
/// workflow yet — that's Phase 3, built on top of the business-logic
/// layer (Phase 2), built on top of this data layer.
///
/// What this screen proves, on a real device, before either of those
/// layers gets written: the database opens, the schema creates
/// correctly, migrations run, and the four system accounts seed as
/// expected. That's the whole point of shipping this as its own
/// checkpoint instead of the entire app at once.
void main() {
  runApp(const AmazosApp());
}

class AmazosApp extends StatelessWidget {
  const AmazosApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Amazos',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF14532D),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorSchemeSeed: const Color(0xFF14532D),
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: const DataLayerCheckScreen(),
    );
  }
}

class DataLayerCheckScreen extends StatefulWidget {
  const DataLayerCheckScreen({super.key});

  @override
  State<DataLayerCheckScreen> createState() => _DataLayerCheckScreenState();
}

class _DataLayerCheckScreenState extends State<DataLayerCheckScreen> {
  late final Future<List<String>> _accountSummaries;

  @override
  void initState() {
    super.initState();
    _accountSummaries = _loadSystemAccounts();
  }

  Future<List<String>> _loadSystemAccounts() async {
    final AccountRepository repo = AccountRepository(DatabaseHelper.instance);
    final accounts = await repo.getAccounts();
    return accounts.map((a) => '${a.name}  —  ${a.type}, ${a.currency}').toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Amazos — Data Layer Check')),
      body: FutureBuilder<List<String>>(
        future: _accountSummaries,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'Database error:\n${snapshot.error}',
                  style: const TextStyle(color: Colors.red),
                ),
              ),
            );
          }
          final names = snapshot.data ?? const <String>[];
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text(
                'Database opened successfully.\nSystem accounts seeded:',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 12),
              ...names.map(
                (n) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Text('•  $n'),
                ),
              ),
              const SizedBox(height: 24),
              const Divider(),
              const SizedBox(height: 12),
              const Text(
                'Phase 1 (data layer) complete. Cash Register UI, reports, '
                'and currency-exchange logic land in later phases.',
                style: TextStyle(color: Colors.grey),
              ),
            ],
          );
        },
      ),
    );
  }
}
