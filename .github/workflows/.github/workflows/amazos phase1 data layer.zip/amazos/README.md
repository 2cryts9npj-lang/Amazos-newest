# Amazos — Phase 1: Data Layer

Cash Movement Operating System. This is **Phase 1 only**: schema,
migrations, models, and repositories. No Cash Register UI, no reports,
no currency-exchange service yet — see "Not in this phase" below.

`lib/main.dart` boots the database, seeds the four system accounts, and
displays them. That's the whole app for now. Its only job is to prove
the data layer works on a real device before anything is built on top
of it.

## Build (Gitpod + Codemagic, per the existing workflow)

1. Push this folder as-is to a new GitHub repo (or unzip into one).
2. Open `gitpod.io/#https://github.com/YOUR_USERNAME/YOUR_REPO`.
3. `flutter pub get`
4. Go to codemagic.io, add the repo, start a build targeting Android.
5. Install the APK. You should see "Database opened successfully"
   and the four system accounts listed. If you see a red error message
   instead, something in this layer needs fixing before Phase 2 starts
   — please send the exact error text back.

## What's implemented

- **Schema**: `business_entities`, `fiscal_years`, `accounts`,
  `movements`, `movement_lines`, `notes`, `audit_log` — all indexed per
  the Blueprint's performance rules.
- **Migration framework**: versioned, additive-only `onUpgrade`, ready
  for a Version 2 schema change without touching Version 1's blocks.
- **Multi-line movements**: `MovementRepository.postMovement()` takes
  a list of lines and posts them atomically — sequential number,
  header, every line, every balance update, and the audit log entry
  all commit or roll back together.
- **Reversal**: `reverseMovement()` creates a new posted movement with
  from/to swapped on every line, sets the original's status to
  `reversed`, and never edits any other column on the original.
- **Universal notes**: `notes` table keyed by `entity_type` +
  `entity_id`, so any table's rows can carry notes. `NoteRepository`
  also derives the highest-severity marker and an entity's timeline —
  both are queries, not stored fields.
- **Audit log**: append-only, written inline inside the same db
  transaction as the operation it records.
- **Running balances**: updated atomically on every line, never
  recomputed by scanning `movement_lines`.

## Disclosed decisions (not silently assumed)

These are choices I made to keep the schema buildable; flagging each
one so you can override any of them before Phase 2 locks in on top:

1. **Table names renamed**: `movements`/`movement_lines` instead of the
   Blueprint's `transactions`/`transaction_lines`, so the Dart model
   classes can be called `Movement`/`MovementLine` without colliding
   with sqflite's own `Transaction` type. No business meaning changed.
2. **`reversal_of_movement_id`**: a real foreign key on `movements`,
   instead of the Blueprint's "references the original via a note."
   More consistent with the constitution's own traceability rule than
   parsing note text to find related movements.
3. **Void is only reachable from Draft.** Posted movements can only be
   corrected via reversal, never voided directly — the only reading of
   the lifecycle chain consistent with "correction is performed only
   through reversing movements." If Void should also apply to Reversed
   movements, that's a one-line change in `movement_repository.dart`.
4. **Two extra system accounts seeded**: `Currency Exchange Clearing`
   and `Cash Over/Short`, alongside the Blueprint's named
   `Opening Balance Equity` and `Realized Currency Gain/Loss`. Both are
   used by name in the Blueprint's own Section 2 workflow narrative but
   weren't formally listed as system accounts.
5. **Mixed-currency balance rule**: an account's local-currency
   `running_balance` only updates when a line's currency matches that
   account's own currency; `running_balance_usd` always updates
   regardless. This matters for virtual accounts like the currency
   clearing account, whose local balance isn't meaningful — only its
   USD balance is. This is the single trickiest part of the whole
   model. See the long comment above `_applyBalanceDelta` in
   `movement_repository.dart`.

## Not in this phase

- Cash Register UI, any screen beyond the boot check.
- Reports (Balance Sheet, P&L, Cash Flow, ledgers, statements).
- **CurrencyExchangeService** — the piece that actually implements the
  Blueprint's 5:30 PM exchange example (relieve at average cost, credit
  at market rate, post realized gain/loss as three lines of one
  movement) using `Money.averageCostRate()`. `postMovement()` is
  currency-agnostic on purpose; this service is Phase 2's first task,
  and its first deliverable should be a unit test reproducing that
  exact example against real numbers before anything else is built on
  it.
- Opening-balance UI flow (the repository support is there —
  `isOpeningBalance: true` — but nothing calls it yet).
- Search/filter UI, pagination UI (repository methods exist:
  `search()`, `getAccountLedger(limit, offset)`).
- Fiscal year close-out enforcement (repository can close a year;
  `postMovement` doesn't yet check `is_closed` before accepting a
  movement dated into a closed year — small gap, flagging it here
  rather than silently deferring it).

## Suggested Phase 2 scope

1. `CurrencyExchangeService` (as above), with the 5:30 PM example as a
   test case.
2. Enforce closed-fiscal-year rejection in `postMovement`.
3. Opening-balance flow: create an account, immediately post an
   opening-balance movement from Opening Balance Equity.
4. Decide the Void-from-Reversed question above, if you want it
   different from what's implemented.
